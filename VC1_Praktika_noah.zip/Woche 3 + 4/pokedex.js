const getAndShowInfoOfPokemon = function () {
    let searchTag = document.getElementById('searched').value
    let url = 'https://pokeapi.co/api/v2/pokemon/' + searchTag.toLowerCase() + '/'

    getNewAPIRequestObject(url, 'GET', function (data) {
        let details = document.getElementById('details')
        let statnav = document.getElementById('stats')

        let sprite = document.getElementById('sprite')
        let name = document.getElementById('name')
        let dexNr = document.getElementById('dex')

        console.log(data)
        sprite.src = data.sprites.front_default
        name.innerHTML = data.name
        dexNr.innerHTML = data.id

        statnav.innerHTML = ""
        showStatsAsBarPlot(data.stats)

        getNewAPIRequestObject(data.species.url, 'GET', function (data) {
            let genderrate = document.getElementById('genderrate')
            genderrate.innerHTML = ""

            if (data.gender_rate === -1) {
                genderrate.innerHTML = "<p><b>Has no gender!</b></p>"
            } else {
                showPiChart(data.gender_rate)
            }

            genderrate.removeAttribute('hidden')
        })

        details.removeAttribute('hidden')
        statnav.removeAttribute('hidden')

    })
}

const showStatsAsBarPlot = function(stats) {
    // set the dimensions and margins of the graph
    var margin = {top: 20, right: 30, bottom: 40, left: 90},
        width = 460 - margin.left - margin.right,
        height = 400 - margin.top - margin.bottom;

    // append the svg object to the body of the page
    var svg = d3.select("#stats")
      .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
      .append("g")
        .attr("transform",
              "translate(" + margin.left + "," + margin.top + ")");

    // Parse the Data
    var data = []
    var counter = 0
    stats.forEach(stat => {
        data[counter] = {statvalue: stat.base_stat, statname: stat.stat.name}
        counter = counter + 1
    })

    // Add X axis
    var x = d3.scaleLinear()
    .domain([0, 300])
    .range([ 0, width]);
    svg.append("g")
    .attr("transform", "translate(0," + height + ")")
    .call(d3.axisBottom(x))
    .selectAll("text")
    .attr("transform", "translate(-10,0)rotate(-45)")
    .style("text-anchor", "end");

    // Y axis
    var y = d3.scaleBand()
    .range([ 0, height ])
    .domain(data.map(function(d) { return d.statname; }))
    .padding(.1);
    svg.append("g")
    .call(d3.axisLeft(y))

    //Bars
    svg.selectAll("myRect")
    .data(data)
    .enter()
    .append("rect")
    .attr("x", x(0) )
    .attr("y", function(d) { return y(d.statname); })
    .attr("width", function(d) { return x(d.statvalue); })
    .attr("height", y.bandwidth() )
    .attr("fill", "#69b3a2")

}

const showPiChart = function (rate_to_female) {

    // set the dimensions and margins of the graph
    var width = 450
        height = 450
        margin = 40

    // The radius of the pieplot is half the width or half the height (smallest one). I subtract a bit of margin.
    var radius = Math.min(width, height) / 2 - margin

    // append the svg object to the div called 'my_dataviz'
    var svg = d3.select("#genderrate")
      .append("svg")
        .attr("width", width)
        .attr("height", height)
      .append("g")
        .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");

    // data
    let rate_to_male = 8
    var data = {male: rate_to_male - rate_to_female, female: rate_to_female}

    // set the color scale
    var color = d3.scaleOrdinal()
      .domain(data)
      .range(["#89cff0", "#f4c2c2"]);

    // Compute the position of each group on the pie:
    var pie = d3.pie()
      .value(function(d) {return d.value; })
    var data_ready = pie(d3.entries(data))
    // Now I know that group A goes from 0 degrees to x degrees and so on.

    // shape helper to build arcs:
    var arcGenerator = d3.arc()
      .innerRadius(0)
      .outerRadius(radius)

    // Build the pie chart: Basically, each part of the pie is a path that we build using the arc function.
    svg
      .selectAll('mySlices')
      .data(data_ready)
      .enter()
      .append('path')
        .attr('d', arcGenerator)
        .attr('fill', function(d){ return(color(d.data.key)) })
        .attr("stroke", "black")
        .style("stroke-width", "2px")
        .style("opacity", 0.7)

    // Now add the annotation. Use the centroid method to get the best coordinates
    svg
      .selectAll('mySlices')
      .data(data_ready)
      .enter()
      .append('text')
      .text(function(d){ return d.data.key})
      .attr("transform", function(d) { return "translate(" + arcGenerator.centroid(d) + ")";  })
      .style("text-anchor", "middle")
      .style("font-size", 17)

}

const getNewAPIRequestObject = function (url, method, onload) {
    let xhr = new XMLHttpRequest()

    xhr.open(method, url)
    xhr.onload = function () {
        let data = JSON.parse(xhr.responseText)
        onload(data)
    }
    xhr.send()
}