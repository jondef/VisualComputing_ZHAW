import cv2 as cv
import numpy as np

img = cv.imread("reallyBlack.png", 1)



